fx_version 'cerulean'
game 'gta5'

author 'Dakhchich'



this_is_a_map 'yes'

